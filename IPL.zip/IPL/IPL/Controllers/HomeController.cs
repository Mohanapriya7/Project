﻿using IPL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IPL.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home

        public ActionResult Login()

        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login user)
        {
            using (Sep19CHNEntities db = new Sep19CHNEntities())
            {
                var usr = db.Logins.Single(u => u.UserName == user.UserName && u.UserPassword == user.UserPassword);
                if (usr != null)
                {
                    Session["UserName"] = usr.UserName.ToString();
                    Session["Password"] = usr.UserPassword.ToString();
                    Session["LoginAs"] = usr.LoginAs.ToString();
                    return RedirectToAction("LoggedIn");

                }
                else
                {
                    ModelState.AddModelError("", "Username or password is Incorrect");
                }


            }
            return View();
        }
        public ActionResult LoggedIn()
        {
            if (Session["UserName"] != null)
                return View();
            else
                return RedirectToAction("Login");
        }
    }
}